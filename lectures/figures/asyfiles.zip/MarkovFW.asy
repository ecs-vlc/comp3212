size(400,200, IgnoreAspect);
import myutil;
import gsl;

int PP = 100;
real s = 0.2;
real u = 0.05;
real v = 0.05;


real psm(int n) {
  return ((1-v)*(1+s)*n+u*(PP-n))/(PP+s*n);
}

real[] p = array(PP+1,0);
p[0] = 1;

real[][] WW = new real[PP+1][PP+1];

for(int i=0; i<=PP; ++i) {
  real pp = psm(i);
  real lp = log(pp);
  real lq = log1p(-pp);
  for(int j=0; j<=PP; ++j) {
    WW[j][i] = exp(lnchoose(PP,j)+j*lp+(PP-j)*lq);
  }
}

void axes() {
  label("$P="+string(PP)+",\,s="+string(s,2)+",\,u="+string(u,2)+",\,v="+string(v,2)+"$", (0.55*PP, 1), N);
  draw((0,1.1)--(0,0)--(1.1*PP,0), Arrows);
  label("Number of Mutants in Population, $n$", (0.55*PP, -0.1));
  label("$p_n(t)$", (0.1*PP, 0.55), W);
  for(int i=0; i<=PP+3; i+=10) {
    label(string(i), (i+0.5,0), S);
  }
  bool show = true;
  for(real x=0.0; x<1.0001; x += 0.1) {
    if (show) {
      draw((0,x)--(-2,x));
      label(string(x,1), (-2,x), W);
    } else
      draw((0,x)--(-1,x));
  }
}

void drawPop(real[] p, pen col=blue+linewidth(1)) {
  guide g = (0,0);
  for(int i=0; i<PP; ++i) {
    g = g--(i, p[i])--(i+1, p[i]);
  }
  g = g--(PP+1.0,0);
  draw(g, col);
}

for(int t=0; t<=25; ++t) {
  label("$t="+string(t)+"$", (0.55*PP,1),S);
  axes();
  drawPop(p);
  ship();
  erase();
  drawPop(p, gray);
  p = WW*p;
}
